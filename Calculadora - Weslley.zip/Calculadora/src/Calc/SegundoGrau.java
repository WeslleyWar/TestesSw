package Calc;

import java.util.Scanner;
 
class SegundoGrau {
 
    public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
 
	    System.out.println("Insira o valor de a:");
	    int a = sc.nextInt();
 
        System.out.println("Insira o valor de b:");
        int b = sc.nextInt();
 
         System.out.println("Insira o valor de c:");
         int c = sc.nextInt();
 
        double pB = Math.pow(b, 2);
        double delta = pB - 4 * a * c;
        double x1 = -1 * pB + Math.sqrt(Math.abs(delta)) / 2 * a;
        double x2 = -1 * pB - Math.sqrt(Math.abs(delta)) / 2 * a;
 
        double r1 = Math.round(x1);
        double r2 = Math.round(x2);
 
        if(delta < 0) {
        	System.out.println("A ra�z x1 vale: "+ x1 + "i");
        	System.out.println("A ra�z x2 vale: "+ x2 + "i");
        } else {
        	System.out.println("A ra�z x1 vale: "+ x1);
        	System.out.println("A ra�z x2 vale: "+ x2);
        }
        sc.close();
    }
}