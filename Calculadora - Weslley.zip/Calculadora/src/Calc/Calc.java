package Calc;

import java.util.Scanner;

public class Calc {
	
	public static void main(String[] args) {
		int num1;
		int num2;
		int res;
		float res2;
		char op;
		
		Scanner leitor = new Scanner(System.in);
		
		System.out.println("Informe o primeiro valor:");
		num1 = leitor.nextInt();
		System.out.println("Informe o segundo valor:");
		num2 = leitor.nextInt();
		
		System.out.println("Informe a opera��o conforme abaixo");
		System.out.println("+ Soma, - Subtra��o, * Multiplica��o, ");
		System.out.println("/ Divis�o, ^ Pot�ncia��o, @ Raiz Quadrada,");
		System.out.println("# Equa��o de Segundo Grau");
		op = leitor.next().charAt(0);
		if(op == '+') {
			res = num1+num2;
			System.out.println("Resultado: "+ res);
		}else { 
			if(op == '-') {
				res = num1-num2;
				System.out.println("Resultado: "+ res);
			}else {
				if(op == '*') {
					res = num1*num2;
					System.out.println("Resultado: "+ res);
				}else {
					if(op == '/') {
						res2 = num1/num2;
						System.out.println("Resultado: "+ res2);
					}else {
						if(op == '^') {
							res2 = (float)Math.pow(num1, num2);
							System.out.println("Resultado: "+ res2);
						}else {
							if(op == '@') {
								res2 = (float)Math.sqrt(num1);
								res = (int) Math.sqrt(num2);
								System.out.println("Resultado do primeiro numero: "+ res2);
								System.out.println("Resultado do segundo numero: "+ res);
							}else {
								if(op == '#') {
									System.out.println("Voc� ser� redirecionado para uma nova tela");
									System.out.println("Favor preencher as informa��es requeridas");
									SegundoGrau.main(args);
								}
							}
						}
					}
				}
			}
		}
			
	leitor.close();
	}
	
}
